extends Area2D

@export var speed: float = 780.0
var direction: Vector2 = Vector2.RIGHT
var life: float = 1.4

func _ready() -> void:
    body_entered.connect(_on_body_entered)
    area_entered.connect(_on_area_entered)

func _physics_process(delta: float) -> void:
    global_position += direction.normalized() * speed * delta
    life -= delta
    if life <= 0.0 or not Rect2(Vector2.ZERO, Vector2(960, 540)).has_point(global_position):
        queue_free()

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("enemies") and body.has_method("take_hit"):
        body.take_hit()
        queue_free()

func _on_area_entered(_area: Area2D) -> void:
    pass
