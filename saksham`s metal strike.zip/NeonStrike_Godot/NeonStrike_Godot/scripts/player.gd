extends CharacterBody2D

const BULLET_SCENE: PackedScene = preload("res://scenes/Bullet.tscn")
@export var move_speed: float = 300.0
@export var fire_rate: float = 0.18
var fire_timer: float = 0.0
var health: int = 100
var invulnerability: float = 0.0

func _physics_process(delta: float) -> void:
    fire_timer = maxf(0.0, fire_timer - delta)
    invulnerability = maxf(0.0, invulnerability - delta)
    var input_dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    velocity = input_dir * move_speed
    move_and_slide()
    global_position.x = clampf(global_position.x, 26.0, 934.0)
    global_position.y = clampf(global_position.y, 26.0, 474.0)
    look_at(get_global_mouse_position())
    if Input.is_action_pressed("shoot") and fire_timer <= 0.0:
        shoot()
        fire_timer = fire_rate
    if invulnerability > 0.0:
        modulate.a = 0.55 if int(Time.get_ticks_msec() / 90) % 2 == 0 else 1.0
    else:
        modulate.a = 1.0

func shoot() -> void:
    var bullet := BULLET_SCENE.instantiate()
    bullet.global_position = global_position + Vector2.RIGHT.rotated(global_rotation) * 34.0
    bullet.direction = Vector2.RIGHT.rotated(global_rotation)
    get_tree().current_scene.add_child(bullet)

func take_damage(amount: int) -> void:
    if invulnerability > 0.0:
        return
    health = maxi(0, health - amount)
    invulnerability = 0.65
    if health <= 0:
        get_tree().call_group("game_manager", "player_died")
