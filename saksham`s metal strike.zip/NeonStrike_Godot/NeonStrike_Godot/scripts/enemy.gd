extends CharacterBody2D

@export var move_speed: float = 105.0
var target: Node2D
var health: int = 2
var attack_cooldown: float = 0.0

func _ready() -> void:
    add_to_group("enemies")
    target = get_tree().get_first_node_in_group("player") as Node2D

func _physics_process(delta: float) -> void:
    if not is_instance_valid(target):
        return
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    var to_player := target.global_position - global_position
    if to_player.length() > 30.0:
        velocity = to_player.normalized() * move_speed
        move_and_slide()
    look_at(target.global_position)
    if to_player.length() < 48.0 and attack_cooldown <= 0.0:
        target.take_damage(12)
        attack_cooldown = 0.75

func take_hit() -> void:
    health -= 1
    if health <= 0:
        get_tree().call_group("game_manager", "enemy_killed")
        queue_free()
