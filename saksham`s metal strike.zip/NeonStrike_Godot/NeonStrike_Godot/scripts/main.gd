extends Node2D

const ENEMY_SCENE: PackedScene = preload("res://scenes/Enemy.tscn")
@onready var player: CharacterBody2D = $Player
@onready var score_label: Label = $HUD/ScoreLabel
@onready var health_label: Label = $HUD/HealthLabel
@onready var message_label: Label = $HUD/MessageLabel

var score: int = 0
var spawn_timer: float = 1.0
var spawn_interval: float = 1.35
var game_over: bool = false

func _ready() -> void:
    add_to_group("game_manager")
    player.add_to_group("player")
    randomize()
    message_label.text = "NEON STRIKE"
    await get_tree().create_timer(1.2).timeout
    if not game_over:
        message_label.text = ""

func _process(delta: float) -> void:
    if game_over:
        if Input.is_action_just_pressed("restart"):
            get_tree().reload_current_scene()
        return
    health_label.text = "HEALTH  %d" % player.health
    score_label.text = "SCORE  %d" % score
    spawn_timer -= delta
    if spawn_timer <= 0.0:
        spawn_enemy()
        spawn_interval = maxf(0.42, spawn_interval * 0.985)
        spawn_timer = spawn_interval

func spawn_enemy() -> void:
    var enemy := ENEMY_SCENE.instantiate()
    var side := randi_range(0, 3)
    var pos := Vector2.ZERO
    match side:
        0: pos = Vector2(randf_range(40, 920), 20)
        1: pos = Vector2(940, randf_range(40, 480))
        2: pos = Vector2(randf_range(40, 920), 520)
        _: pos = Vector2(20, randf_range(40, 480))
    enemy.global_position = pos
    enemy.move_speed += minf(65.0, score * 0.35)
    add_child(enemy)

func enemy_killed() -> void:
    score += 10

func player_died() -> void:
    if game_over:
        return
    game_over = true
    message_label.text = "GAME OVER\nSCORE: %d\nPRESS R TO RESTART" % score
    get_tree().call_group("enemies", "set_physics_process", false)
