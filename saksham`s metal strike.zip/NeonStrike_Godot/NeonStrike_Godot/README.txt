NEON STRIKE - Godot 2D arena shooter
=====================================

REQUIREMENTS
- Godot Engine 4.2 or newer (Godot 4.x recommended).

RUN
1. Extract NeonStrike_Godot.zip.
2. Open Godot Project Manager.
3. Click Import and select the project.godot file inside this folder.
4. Open the project and press F6 (run current scene) or F5 (run project).

CONTROLS
- WASD or Arrow Keys: move
- Mouse: aim
- Left Mouse Button or Space: shoot
- R: restart after game over
- Esc: Godot's standard window close behavior

GAMEPLAY
Survive waves of enemies, aim with the mouse, and shoot. Enemies approach from the arena edges.
Each enemy takes two hits. Contact damages the player. Enemy speed and spawn rate increase
gradually as your score rises.

PROJECT CONTENTS
- project.godot: project settings and main scene
- scenes/: Main, Player, Enemy, Bullet scenes
- scripts/: GDScript logic
- assets/: generated PNG sprites and arena background

All gameplay art is original, generated for this project. No external asset downloads required.
